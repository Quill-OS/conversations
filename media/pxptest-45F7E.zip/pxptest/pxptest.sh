export ADDSPATH=/mnt/onboard/.adds
export SPATH=${ADDSPATH}/pxptest

LOGFILE=${SPATH}/log.txt

sh ${SPATH}/exit_nickel.sh

# set portrait mode
${SPATH}/fbdepth -r -1

# save old bit depth
ORIG_BPP=$(${SPATH}/fbdepth -g)

# set 8bit screen depth
[ "$ORIG_BPP" ] && ${SPATH}/fbdepth -q -d 8

${SPATH}/PXPtest -I " " >$LOGFILE 2>&1


# restore old bit depth
[ "$ORIG_BPP" ] && ${SPATH}/fbdepth -q -d "$ORIG_BPP"

sleep 5

sh ${SPATH}/start_nickel.sh
