#!/bin/sh

ENVFILE=${UMRPATH}/saved_env

eval "$(xargs -n 1 -0 <"/proc/$(pidof nickel)/environ" | grep -e DBUS_SESSION_BUS_ADDRESS -e NICKEL_HOME -e WIFI_MODULE -e LANG -e WIFI_MODULE_PATH -e INTERFACE 2>/dev/null)"
export DBUS_SESSION_BUS_ADDRESS NICKEL_HOME WIFI_MODULE LANG WIFI_MODULE_PATH INTERFACE

export ORIGINAL_FB_ROTATION="$(cat /sys/class/graphics/fb0/rotate)"

export -p > ${ENVFILE}

sync
    
killall -TERM nickel hindenburg sickel fickel fmon kfmon 2>/dev/null
