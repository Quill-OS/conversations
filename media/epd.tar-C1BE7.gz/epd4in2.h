#define EPD_WIDTH 400
#define EPD_HEIGHT 300
void epd_init();
void epd_display_full(uint8_t *old, uint8_t *buffer);
void epd_sleep();
