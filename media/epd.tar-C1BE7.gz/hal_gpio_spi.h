// SPDX-License-Identifier: GPL-2.0+
// Copyright (C) 2018 Andreas Kemnade

int hal_gpio_spi_init();
int hal_spi_rw(const unsigned char *w, unsigned char *r, unsigned int len);
int hal_gpio_out(int gpio, int value);
int hal_gpio_in(int gpio);
