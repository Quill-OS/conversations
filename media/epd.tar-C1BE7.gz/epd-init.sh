#!/bin/bash
EPD_GROUP=plugdev
for name in 2 3 68 ; do
echo $name >/sys/class/gpio/export
chgrp $EPD_GROUP /sys/class/gpio/gpio$name/value
chmod g+rw  /sys/class/gpio/gpio$name/value
done
for name in 2 3 ; do
echo out >/sys/class/gpio/gpio$name/direction
done
gpio mode 5 in
chgrp $EPD_GROUP /dev/spidev0.0
chmod 660 /dev/spidev0.0
