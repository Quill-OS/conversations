// SPDX-License-Identifier: GPL-2.0+
// Copyright (C) 2018 Andreas Kemnade

#include <unistd.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "epd4in2.h"
static void invert_buf(uint8_t *buf, int len)
{
   int i;
   for(i = 0; i < len; i++) {
     buf[i] = ~buf[i];
   }
}

uint8_t *load_pbm(char *fname, int *w, int *h)
{
  FILE *f;
  uint8_t *imgbuf;
  char header[256];
  f = fopen(fname, "r");
  if (f == NULL) {
    fprintf(stderr, "cannot open %s\n", fname);
    return NULL;
  }
  if (!fgets(header, sizeof(header),f)) {
    fclose(f);
    return NULL;
  }
  if (strncmp(header, "P4", 2)) {
    fprintf(stderr, "invalid format\n");
    fclose(f);
    return NULL;
  }
  do {
    if (!fgets(header, sizeof(header),f)) {
      fclose(f);
      return NULL;
    }
  } while(header[0]=='#');
  sscanf(header, "%d %d", w, h);
  if ((*w > 400) || (*h > 300) || ((*w)&7)) {
    fprintf(stderr, "invalid size\n");
    fclose(f);
    return NULL;
  }
  imgbuf = malloc((*w)*(*h)/8);
  fread(imgbuf, 1, (*w)*(*h)/8, f);
  fclose(f);
  return imgbuf;
}

int main(int argc, char **argv)
{
  uint8_t *old_img;
  uint8_t *new_img;
  int w_old, w, h_old, h, x,y;
  char *old_f = NULL;
  if (argc < 2) {
    fprintf(stderr, "%s [old.pbm] new.pbm [x y]\n", argv[0]);
    return 1;
  }
  if (argc & 1) {
    old_f = argv[1];
    argc--;
    argv++;
  }

  if (argc == 4) {
    x = atoi(argv[2]);
    y = atoi(argv[3]);
  } else {
    x = 0;
    y = 0;
  }
  
  new_img = load_pbm(argv[1], &w, &h);
  old_img = NULL;
  if (old_f) 
    old_img = load_pbm(old_f, &w_old, &h_old);
  if (!old_img) {
    fprintf(stderr, "no old data!\n");
    old_img = malloc(w*h/8);
    w_old = w;
    h_old = h;
    memset(old_img, 0xff, w*h/8);
  } else {
    invert_buf(old_img, w*h/8);
  }
  if ((old_img == NULL) || (new_img == NULL) || (w_old != w) || (h_old != h)) {
    fprintf(stderr, "invalid input, aborting\n");
    return 1;
  }
  invert_buf(new_img, w*h/8);
 
  epd_init();
  if ((w == 400) && (h == 300)) {
    epd_display_full(old_img, new_img);
  } else {
    epd_display_full_partial(old_img, new_img, x, y, w, h);
  }
  epd_sleep();
}
