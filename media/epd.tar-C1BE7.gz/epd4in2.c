// SPDX-License-Identifier: GPL-2.0+
// Copyright (C) 2018 Andreas Kemnade

#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "hal_gpio_spi.h"
#include "epd4in2.h"
#define GPIO_BUSY 64+4
#define GPIO_RST 0
#define GPIO_DC 2
//#define GPIO_CS 5

static void reset()
{
  hal_gpio_out(GPIO_RST, 0);
  usleep(200000);
  hal_gpio_out(GPIO_RST, 1);
  usleep(200000);
}

static void send_command(uint8_t cmd, uint8_t *data, int len)
{
  hal_gpio_out(GPIO_DC, 0);
  hal_spi_rw(&cmd, NULL, 1);
  hal_gpio_out(GPIO_DC, 1);
  if (data)
    hal_spi_rw(data, NULL, len); 
}

static void wait_ready()
{
  int res;
  while((res = hal_gpio_in(GPIO_BUSY)) == 0) {
    if (res < 0) {
      fprintf(stderr, "busy read error\n");
      exit(1);
    }
    usleep(100000);
  }      

}


void epd_init()
{
  hal_gpio_spi_init();
  reset();
  /* power setting */
  // send_command(0x01, "x03\0x00\0x2b\0x2b\0xff", 5);
  /* booster soft start */
  send_command(0x06, "\x17\x17\x17", 3);
  
  /* power on */
  send_command(4, NULL, 0);

  wait_ready();

  /* panel setting */
  send_command(0x00, "\x1f", 1);
}

void epd_display_full_partial(uint8_t *old, uint8_t *buffer, int x, int y, int w, int h)
{
  int i;
  /* resolution setting */
  uint8_t res_setting[9];
  if ((x & 7) || (w & 7) || (x+w > EPD_WIDTH) || (y+h > EPD_HEIGHT))
    return;

  res_setting[0] = EPD_WIDTH >> 8;
  res_setting[1] = EPD_WIDTH & 0xff;
  res_setting[2] = EPD_HEIGHT >> 8;
  res_setting[3] = EPD_HEIGHT & 0xff;
  send_command(0x61 , res_setting, 4);

  /* vcom, data interval */
  send_command(0x50, "\xD7", 1);

  /* partial in */
  send_command(0x91, NULL, 0);

  /* partial window */
  res_setting[0] = x >> 8;
  res_setting[1] = x & 0xF8;
  res_setting[2] = ((x & 0x1f8) + w - 1) >> 8;
  res_setting[3] = ((x & 0x1f8) + w - 1) | 0x07;
  res_setting[4] = y >> 8;
  res_setting[5] = y & 0xff;
  res_setting[6] = (y + h -1) >> 8;
  res_setting[7] = (y + h -1) & 0xff;
  /* no refresh of not-affected locations */
  res_setting[8] = 0;
  send_command(0x90, res_setting, 8);
  send_command(0x10, NULL, 0); 
  hal_gpio_out(GPIO_DC, 1);
  for(i = 0;i < h; i++) {
    hal_spi_rw(old, NULL, w / 8);
    old += w / 8;
  }
  usleep(1000);
  send_command(0x13, NULL, 0);
  for(i = 0;i < h; i++) {
    hal_spi_rw(buffer, NULL, w / 8);
    buffer += w / 8;
  }
  send_command(0x12, NULL, 0);
  wait_ready();
}

void epd_display_full(uint8_t *old, uint8_t *buffer)
{
  int i;
  /* resolution setting */
  uint8_t res_setting[4];
  res_setting[0] = EPD_WIDTH >> 8;
  res_setting[1] = EPD_WIDTH & 0xff;
  res_setting[2] = EPD_HEIGHT >> 8;
  res_setting[3] = EPD_HEIGHT & 0xff;
  send_command(0x61 , res_setting, 4);

  /* vcom, data interval */
  send_command(0x50, "\x97", 1);

  send_command(0x10, NULL, 0); 
  hal_gpio_out(GPIO_DC, 1);
  for(i = 0;i < EPD_HEIGHT; i++) {
    hal_spi_rw(old, NULL, EPD_WIDTH / 8);
    old += EPD_WIDTH / 8;
  }
  usleep(1000);
  send_command(0x13, NULL, 0);
  for(i = 0;i < EPD_HEIGHT; i++) {
    hal_spi_rw(buffer, NULL, EPD_WIDTH / 8);
    buffer += EPD_WIDTH / 8;
  }
  send_command(0x12, NULL, 0);
  wait_ready();
}

void epd_sleep()
{
  send_command(0x50, "\x17", 1);
  send_command(0x02, NULL, 0);
  send_command(0x07, "\xa5", 1);
}
