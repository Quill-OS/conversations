// SPDX-License-Identifier: GPL-2.0+
// Copyright (C) 2018 Andreas Kemnade

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/file.h>
#include <linux/spi/spidev.h>
#include <stdlib.h>
#include <string.h>

static int spifd;

int hal_gpio_spi_init()
{
  int mode = 0; /* 0,1.2.3 */
  spifd = open("/dev/spidev0.0",O_RDWR);
  if (spifd<0) {
    return -1;
  }

  if (0 > flock(spifd, LOCK_EX)) {
    return -1;
  }

  ioctl(spifd, SPI_IOC_WR_MODE, &mode);
  return 0;
}

int hal_spi_rw(const unsigned char *w, unsigned char *r, unsigned int len)
{
  int ret;
  struct spi_ioc_transfer spi;
  memset(&spi, 0, sizeof(spi));
  spi.tx_buf = w;
  spi.rx_buf = r;
  spi.len = len;
  spi.speed_hz = 200000;
  spi.bits_per_word = 8;
  spi.cs_change = 1;
  spi.delay_usecs = 4;
  ret= ioctl(spifd, SPI_IOC_MESSAGE(1), &spi);
  if (ret <= 0)
    printf("rw result: %d\n", ret);
}

int hal_gpio_out(int gpio, int value)
{
  char buf[80];
  int fd;
  snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);
  fd = open(buf, O_WRONLY);
  if (fd < 0) {
    fprintf(stderr, "cannot access %s\n", buf);
    return -1;
  }
  write(fd, value ? "1": "0", 1);
  close(fd);
  return 0;
}

int hal_gpio_in(int gpio)
{
  char buf[80];
  int fd;
  int l;
  snprintf(buf, sizeof(buf), "/sys/class/gpio/gpio%d/value", gpio);
  fd = open(buf, O_RDONLY);
  if (fd < 0) {
    fprintf(stderr, "cannot access %s\n", buf);
    return -1;
  }
  memset(buf, 0, sizeof(buf));
  l = read(fd, buf, 16);
  close(fd);
  if (l < 0) 
    return -1;
  return atoi(buf);
}
