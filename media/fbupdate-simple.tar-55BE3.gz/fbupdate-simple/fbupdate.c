#include <sys/ioctl.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include <linux/fb.h>
#include "mxcfb.h"
#include <stdint.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv)
{
  int fd = open("/dev/fb0", O_RDWR);
  if (fd < 0) {
    perror("failed to open fd");
    return 1;
  }
  if (argc == 2) {
    uint32_t t = atoi(argv[1]);
    int ret = ioctl(fd,MXCFB_SET_AUTO_UPDATE_MODE, &t);
    if (ret < 0) {
      perror("ioctl set update");
      return 1;
    }
  } else if (argc == 6) {
    int ret;
    struct mxcfb_update_data upd_region;
    memset(&upd_region, 0, sizeof(upd_region));
    upd_region.update_region.left = atoi(argv[1]);
    upd_region.update_region.top = atoi(argv[2]);
    upd_region.update_region.width = atoi(argv[3]);
    upd_region.update_region.height = atoi(argv[4]);
    upd_region.waveform_mode = WAVEFORM_MODE_AUTO;
    upd_region.temp = TEMP_USE_AMBIENT;
    upd_region.update_mode = strcmp(argv[5],"full") ? 
	UPDATE_MODE_PARTIAL : UPDATE_MODE_FULL;
    upd_region.flags = 0;
    ret = ioctl(fd, MXCFB_SEND_UPDATE, &upd_region);
    if (ret < 0) perror("ioctl update");
  }
  return 0;
}

