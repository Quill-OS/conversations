#include <stdio.h>

#define NUM_X 150+2

#define NUM_Y 75+2
#define OVER_RELAXATION 1.9
#define DENSITY 1000.0
#define NUM_CELLS NUM_X*NUM_Y
#define H 0.01

float gU[NUM_CELLS];
float gV[NUM_CELLS];
float gNEW_U[NUM_CELLS];
float gNEW_V[NUM_CELLS];
float gP[NUM_CELLS];
float gS[NUM_CELLS];
float gM[NUM_CELLS];
float gNEW_M[NUM_CELLS];

const int WIDTH =NUM_Y;
const int HEIGHT=NUM_X;

float floor32(float a);

void setWallsAndIncoming(float u[], float s[], float m[]);

void set_obstacle(float x, float y, float s[],float u[],float v[],float m[]);

void integrate(float dt, float gravity, float s[],float v[]);

void solveIncompressibility(size_t numIters,
	float dt,float s[], float u[], float v[], float P[]);

void extrapolate(float u[], float v[]);

float max32(float x, float y);

float min32(float x, float y);

float sampleField(float xi, float yi, char field, float f[]);

float avgU(int i, int j, float u[]);

float avgV(int i, int j, float v[]);

void advectVel(float dt, float u[], float newU[], float v[], float newV[], float s[]);


void advectSmoke(float dt, float m[], float newM[], float s[], float u[], float v[]);


void simulate(float dt, float gravity, size_t numIters, float u[], float newU[], float v[], float newV[], float s[], float P[], float m[], float newM[]);

//float floor(int a){
//    return (float) ((int) a);
//}

//for (int i=0; i<NUM_CELLS, ++i){
//
    
//}
//
float floor32(float a){
    return (float) ((int)a);
}

void main(void) {
    printf(" %i\n", NUM_X);
    
    setWallsAndIncoming(gU, gS, gM);
}




void setWallsAndIncoming(float u[], float s[], float m[]){
    printf("function entered\n");
    int n=NUM_Y;
    float inVel=2.0;
    for (int i=0; i<NUM_X;++i){
	for (int j=0; j<NUM_Y;++j){
	    float s_loc=1.0;
	    if (i==0 || j==0 || j==NUM_Y-1){
		s_loc=0.0;

	    }
	    s[i*n+j]=s_loc;
	    if (i<=1){
		u[i*n+j]=inVel;
	    }
	}
    }
    printf("first loop completed");
    float pipeH=0.1* ((float) NUM_Y);
    int minJ=(int) floor32(0.5*((float)NUM_Y)-0.5*pipeH);
    int maxJ=(int) floor32(0.5*((float)NUM_Y)+0.5*pipeH);
    for (int i=0; i<2; ++i){
	for (int j=minJ; j<maxJ-1; ++j){
	    m[i*n+j]=0.0;
	}

    }
    printf("second loop completed");
}


